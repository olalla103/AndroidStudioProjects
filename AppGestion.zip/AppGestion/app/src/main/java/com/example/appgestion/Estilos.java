package com.example.appgestion;

public enum Estilos {
    Femenino, Masculino, Neutro
}
