// Actualización de AniadirElemento para usar PrendaRopa
package com.example.appgestion;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

public class AniadirElemento extends AppCompatActivity {

    private EditText tipoPrenda, descripcionPrenda;
    private Spinner estiloPrenda;
    private Button botonAceptar, botonCancelar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aniadir_elemento);

        // Inicializar componentes
        tipoPrenda = findViewById(R.id.editTextText); // ID para el campo del tipo de prenda
        descripcionPrenda = findViewById(R.id.editTextTextMultiLine); // ID para la descripción
        estiloPrenda = findViewById(R.id.spinnerEstilo); // Spinner para los estilos
        botonAceptar = findViewById(R.id.button3);
        botonCancelar = findViewById(R.id.button4);

        // Configurar opciones del Spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.estilos_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        estiloPrenda.setAdapter(adapter);

        // Configurar evento para el botón "Aceptar"
        botonAceptar.setOnClickListener(v -> {
            // Obtener datos ingresados
            String tipo = tipoPrenda.getText().toString().trim();
            String descripcion = descripcionPrenda.getText().toString().trim();
            String estiloSeleccionado = estiloPrenda.getSelectedItem().toString();

            // Validar que los datos no estén vacíos
            if (tipo.isEmpty() || descripcion.isEmpty() || estiloSeleccionado.isEmpty()) {
                setResult(RESULT_CANCELED);
                finish();
                return;
            }

            // Pasar datos a la actividad principal
            Intent intent = new Intent();
            intent.putExtra("tipo", tipo);
            intent.putExtra("descripcion", descripcion);
            intent.putExtra("estilo", estiloSeleccionado);

            setResult(RESULT_OK, intent);
            finish(); // Finalizar la actividad
        });

        // Configurar evento para el botón "Cancelar"
        botonCancelar.setOnClickListener(v -> {
            setResult(RESULT_CANCELED);
            finish();
        });
    }
}
