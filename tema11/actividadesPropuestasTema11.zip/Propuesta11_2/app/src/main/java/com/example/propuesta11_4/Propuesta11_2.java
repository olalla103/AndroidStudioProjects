package com.example.propuesta11_4;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.URL;

public class Propuesta11_2 extends AppCompatActivity {

  /*  @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_propuesta112);
        ImageView miImagen = (ImageView) findViewById(R.id.miImagen);

        // Imagen desde recurso
        Bitmap miBitMap = BitmapFactory.decodeResource(getResources(), miImagen.getId());


        miImagen.setImageBitmap(miBitMap);

    }*/
}